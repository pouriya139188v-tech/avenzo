import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, Pressable, FlatList, Alert, StyleSheet } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { supabase } from './src/supabase';

export default function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [session, setSession] = useState(null);
  const [posts, setPosts] = useState([]);
  const [caption, setCaption] = useState('');

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (session) loadPosts();
  }, [session]);

  async function loadPosts() {
    if (!supabase) return;
    const { data, error } = await supabase.from('posts').select('*').order('created_at', { ascending: false }).limit(30);
    if (error) Alert.alert('خطا', error.message);
    else setPosts(data || []);
  }

  async function signIn() {
    if (!supabase) return Alert.alert('تنظیمات ناقص', 'ابتدا فایل .env را با اطلاعات Supabase تکمیل کنید.');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) Alert.alert('ورود ناموفق', error.message);
  }

  async function signUp() {
    if (!supabase) return Alert.alert('تنظیمات ناقص', 'ابتدا فایل .env را با اطلاعات Supabase تکمیل کنید.');
    const { error } = await supabase.auth.signUp({ email, password });
    if (error) Alert.alert('ثبت‌نام ناموفق', error.message);
    else Alert.alert('ثبت‌نام', 'اگر تأیید ایمیل فعال باشد، ایمیل خود را بررسی کنید.');
  }

  async function publish() {
    if (!caption.trim() || !session) return;
    const { error } = await supabase.from('posts').insert({ user_id: session.user.id, caption: caption.trim() });
    if (error) Alert.alert('خطا', error.message);
    else { setCaption(''); loadPosts(); }
  }

  async function signOut() { await supabase.auth.signOut(); setPosts([]); }

  return (
    <SafeAreaView style={styles.page}>
      <StatusBar style="light" />
      <Text style={styles.logo}>AVENZO</Text>
      <Text style={styles.tag}>Share your world</Text>
      {!session ? (
        <View style={styles.panel}>
          <Text style={styles.heading}>خوش آمدی</Text>
          <TextInput style={styles.input} placeholder="ایمیل" placeholderTextColor="#8d8aa3" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} />
          <TextInput style={styles.input} placeholder="رمز عبور" placeholderTextColor="#8d8aa3" secureTextEntry value={password} onChangeText={setPassword} />
          <Pressable style={styles.primary} onPress={signIn}><Text style={styles.primaryText}>ورود</Text></Pressable>
          <Pressable style={styles.secondary} onPress={signUp}><Text style={styles.secondaryText}>ساخت حساب</Text></Pressable>
          <Text style={styles.note}>فعلاً ورود با ایمیل فعال است؛ ورود پیامکی هنوز راه‌اندازی نشده است.</Text>
        </View>
      ) : (
        <>
          <View style={styles.panel}>
            <Text style={styles.heading}>فید AVENZO</Text>
            <TextInput style={styles.input} placeholder="چه چیزی می‌خواهی به اشتراک بگذاری؟" placeholderTextColor="#8d8aa3" value={caption} onChangeText={setCaption} />
            <Pressable style={styles.primary} onPress={publish}><Text style={styles.primaryText}>انتشار نوشته</Text></Pressable>
            <Pressable onPress={signOut}><Text style={styles.secondaryText}>خروج از حساب</Text></Pressable>
          </View>
          <FlatList data={posts} keyExtractor={(item) => String(item.id)} onRefresh={loadPosts} refreshing={false}
            renderItem={({ item }) => <View style={styles.post}><Text style={styles.postText}>{item.caption || 'پست بدون متن'}</Text></View>}
            ListEmptyComponent={<Text style={styles.note}>هنوز پستی وجود ندارد.</Text>} />
        </>
      )}
      <Text style={styles.footer}>نسخه اولیه آزمایشی • AVENZO</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#10101b', padding: 22, paddingTop: 40 },
  logo: { color: '#f3d18a', fontSize: 34, fontWeight: '900', letterSpacing: 4, textAlign: 'center' },
  tag: { color: '#a6a1bb', textAlign: 'center', marginBottom: 28 },
  panel: { backgroundColor: '#1c1b2b', borderColor: '#5c477d', borderWidth: 1, borderRadius: 20, padding: 18, gap: 12 },
  heading: { color: '#fff', fontSize: 22, fontWeight: '700', marginBottom: 6 },
  input: { backgroundColor: '#29273b', color: '#fff', borderRadius: 12, padding: 14, textAlign: 'right' },
  primary: { backgroundColor: '#b98b48', padding: 14, borderRadius: 12, alignItems: 'center' },
  primaryText: { color: '#17131d', fontWeight: '800' },
  secondary: { borderColor: '#b98b48', borderWidth: 1, padding: 13, borderRadius: 12, alignItems: 'center' },
  secondaryText: { color: '#f0d6a5', textAlign: 'center', padding: 8 },
  note: { color: '#aaa5bb', textAlign: 'center', marginTop: 12, lineHeight: 22 },
  post: { backgroundColor: '#1c1b2b', borderRadius: 14, padding: 16, marginTop: 12 },
  postText: { color: '#fff', fontSize: 16, textAlign: 'right' },
  footer: { color: '#777187', textAlign: 'center', marginTop: 20, marginBottom: 12, fontSize: 11 }
});
